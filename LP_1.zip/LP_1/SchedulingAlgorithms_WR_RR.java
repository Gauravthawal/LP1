import java.util.*;

class Process {
    int processID, arrivalTime, burstTime, priority, waitingTime, turnaroundTime, completionTime, remainingTime;

    public Process(int processID, int arrivalTime, int burstTime, int priority) {
        this.processID = processID;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.priority = priority;
        this.remainingTime = burstTime;
    }
}

public class SchedulingAlgorithms {

    // First Come First Serve (FCFS)
    public static void fcfsScheduling(Process[] processes) {
        int currentTime = 0;

        for (Process p : processes) {
            if (currentTime < p.arrivalTime) {
                currentTime = p.arrivalTime;
            }
            p.waitingTime = currentTime - p.arrivalTime;
            p.completionTime = currentTime + p.burstTime;
            p.turnaroundTime = p.completionTime - p.arrivalTime;
            currentTime += p.burstTime;
        }
        printResults(processes, "FCFS");
    }

    // Shortest Remaining Time First (SRTF) - Preemptive
    public static void srtfScheduling(Process[] processes) {
        int currentTime = 0;
        int completedProcesses = 0;
        int n = processes.length;
        Process currentProcess = null;

        while (completedProcesses < n) {
            Process shortestRemainingProcess = null;

            for (Process p : processes) {
                if (p.arrivalTime <= currentTime && p.remainingTime > 0) {
                    if (shortestRemainingProcess == null || p.remainingTime < shortestRemainingProcess.remainingTime) {
                        shortestRemainingProcess = p;
                    }
                }
            }

            if (shortestRemainingProcess == null) {
                currentTime++;
                continue;
            }

            currentProcess = shortestRemainingProcess;
            currentProcess.remainingTime--;
            currentTime++;

            if (currentProcess.remainingTime == 0) {
                completedProcesses++;
                currentProcess.completionTime = currentTime;
                currentProcess.turnaroundTime = currentProcess.completionTime - currentProcess.arrivalTime;
                currentProcess.waitingTime = currentProcess.turnaroundTime - currentProcess.burstTime;
            }
        }
        printResults(processes, "SRTF (Preemptive)");
    }

    // Priority Scheduling (Non-Preemptive)
    public static void priorityScheduling(Process[] processes) {
        Arrays.sort(processes, Comparator.comparingInt(p -> p.arrivalTime));
        List<Process> processList = new ArrayList<>(Arrays.asList(processes));
        int currentTime = 0;

        while (!processList.isEmpty()) {
            Process highestPriority = null;
            for (Process p : processList) {
                if (p.arrivalTime <= currentTime) {
                    if (highestPriority == null || p.priority < highestPriority.priority) {
                        highestPriority = p;
                    }
                }
            }

            if (highestPriority == null) {
                currentTime++;
                continue;
            }

            highestPriority.waitingTime = currentTime - highestPriority.arrivalTime;
            highestPriority.completionTime = currentTime + highestPriority.burstTime;
            highestPriority.turnaroundTime = highestPriority.completionTime - highestPriority.arrivalTime;
            currentTime += highestPriority.burstTime;
            processList.remove(highestPriority);
        }
        printResults(processes, "Priority (Non-Preemptive)");
    }

    // Round Robin Scheduling
    public static void roundRobinScheduling(Process[] processes, int timeQuantum) {
        Queue<Process> queue = new LinkedList<>(Arrays.asList(processes));
        int currentTime = 0;

        while (!queue.isEmpty()) {
            Process p = queue.poll();

            if (currentTime < p.arrivalTime) {
                currentTime = p.arrivalTime;
            }

            if (p.remainingTime > timeQuantum) {
                p.remainingTime -= timeQuantum;
                currentTime += timeQuantum;
                queue.add(p);
            } else {
                currentTime += p.remainingTime;
                p.completionTime = currentTime;
                p.turnaroundTime = p.completionTime - p.arrivalTime;
                p.waitingTime = p.turnaroundTime - p.burstTime;
                p.remainingTime = 0;
            }
        }
        printResults(processes, "Round Robin");
    }

    // Print scheduling results
    private static void printResults(Process[] processes, String algorithm) {
        System.out.println("\n" + algorithm + " Scheduling Results:");
        System.out.println("Process ID | Arrival Time | Burst Time | Priority | Waiting Time | Turnaround Time | Completion Time");
        for (Process p : processes) {
            System.out.printf("%10d | %12d | %10d | %8d | %12d | %15d | %15d%n",
                    p.processID, p.arrivalTime, p.burstTime, p.priority, p.waitingTime, p.turnaroundTime, p.completionTime);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of processes: ");
        int n = scanner.nextInt();
        Process[] processes = new Process[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for Process " + (i + 1) + ":");
            System.out.print("Arrival Time: ");
            int arrivalTime = scanner.nextInt();
            System.out.print("Burst Time: ");
            int burstTime = scanner.nextInt();
            System.out.print("Priority: ");
            int priority = scanner.nextInt();

            processes[i] = new Process(i + 1, arrivalTime, burstTime, priority);
        }

        // FCFS Scheduling
        fcfsScheduling(processes.clone());

        // SRTF Scheduling
        srtfScheduling(processes.clone());

        // Priority Scheduling
        priorityScheduling(processes.clone());

        // Round Robin Scheduling
        System.out.print("Enter time quantum for Round Robin: ");
        int timeQuantum = scanner.nextInt();
        roundRobinScheduling(processes.clone(), timeQuantum);

        scanner.close();
    }
}
