import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class Symbol {
    String label;
    int address;

    public Symbol(String label, int address) {
        this.label = label;
        this.address = address;
    }
}

class Literal {
    String literal;
    int address;

    public Literal(String literal, int address) {
        this.literal = literal;
        this.address = address;
    }
}

class OpCode {
    String mnemonic;
    int format; // format can indicate the length of instruction, e.g., 1, 2, 3 bytes.

    public OpCode(String mnemonic, int format) {
        this.mnemonic = mnemonic;
        this.format = format;
    }
}

class Instruction {
    String label;
    String operation;
    String operand;

    public Instruction(String label, String operation, String operand) {
        this.label = label;
        this.operation = operation;
        this.operand = operand;
    }
}

class AssemblerPassOne {
    private Map<String, Symbol> symbolTable = new HashMap<>();
    private Map<String, Literal> literalTable = new HashMap<>();
    private Map<String, OpCode> opCodeTable = new HashMap<>();
    private ArrayList<Instruction> instructions = new ArrayList<>();
    private int locationCounter = 0;

    public AssemblerPassOne() {
        initializeOpCodeTable();
    }

    private void initializeOpCodeTable() {
        opCodeTable.put("LDA", new OpCode("LDA", 3));
        opCodeTable.put("STA", new OpCode("STA", 3));
        opCodeTable.put("ADD", new OpCode("ADD", 3));
        opCodeTable.put("SUB", new OpCode("SUB", 3));
        // Add more opcodes as per the pseudo-machine specification
    }

    public void addInstruction(String label, String operation, String operand) {
        Instruction instruction = new Instruction(label, operation, operand);
        instructions.add(instruction);

        // If a label is present, add it to the symbol table with current location counter
        if (label != null && !label.isEmpty()) {
            symbolTable.put(label, new Symbol(label, locationCounter));
        }

        // Update the location counter based on the operation type
        if (opCodeTable.containsKey(operation)) {
            locationCounter += opCodeTable.get(operation).format;
        } else if (operation.equals("WORD")) {
            locationCounter += 3; // Assume a WORD is 3 bytes
        } else if (operation.equals("RESW")) {
            int words = Integer.parseInt(operand);
            locationCounter += 3 * words; // Reserve a number of words
        } else if (operation.equals("RESB")) {
            int bytes = Integer.parseInt(operand);
            locationCounter += bytes; // Reserve a number of bytes
        } else if (operation.equals("BYTE")) {
            locationCounter += 1; // Assuming each BYTE takes 1 byte
        }
    }

    public void processInstructions() {
        for (Instruction instruction : instructions) {
            String operation = instruction.operation;
            String operand = instruction.operand;

            // Handle literals
            if (operand != null && operand.startsWith("=")) {
                if (!literalTable.containsKey(operand)) {
                    literalTable.put(operand, new Literal(operand, locationCounter));
                    locationCounter += 3; // Assume each literal takes 3 bytes
                }
            }
        }
    }

    public void printSymbolTable() {
        System.out.println("Symbol Table:");
        for (Symbol symbol : symbolTable.values()) {
            System.out.println(symbol.label + " -> " + symbol.address);
        }
    }

    public void printLiteralTable() {
        System.out.println("Literal Table:");
        for (Literal literal : literalTable.values()) {
            System.out.println(literal.literal + " -> " + literal.address);
        }
    }

    public static void main(String[] args) {
        AssemblerPassOne assembler = new AssemblerPassOne();
        
        // Example input for Pass 1
        assembler.addInstruction("START", "START", "1000");
        assembler.addInstruction("FIRST", "LDA", "ALPHA");
        assembler.addInstruction("", "ADD", "=5");
        assembler.addInstruction("", "STA", "BETA");
        assembler.addInstruction("ALPHA", "WORD", "1");
        assembler.addInstruction("BETA", "RESW", "1");
        assembler.addInstruction("END", "END", "");

        assembler.processInstructions();

        // Display the symbol and literal tables
        assembler.printSymbolTable();
        assembler.printLiteralTable();
    }
}
