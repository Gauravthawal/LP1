import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class Symbol {
    String label;
    int address;

    public Symbol(String label, int address) {
        this.label = label;
        this.address = address;
    }
}

class Literal {
    String literal;
    int address;

    public Literal(String literal, int address) {
        this.literal = literal;
        this.address = address;
    }
}

class OpCode {
    String mnemonic;
    int format;

    public OpCode(String mnemonic, int format) {
        this.mnemonic = mnemonic;
        this.format = format;
    }
}

class Instruction {
    String label;
    String operation;
    String operand;

    public Instruction(String label, String operation, String operand) {
        this.label = label;
        this.operation = operation;
        this.operand = operand;
    }
}

class AssemblerPassOne {
    protected Map<String, Symbol> symbolTable = new HashMap<>();
    protected Map<String, Literal> literalTable = new HashMap<>();
    protected Map<String, OpCode> opCodeTable = new HashMap<>();
    protected ArrayList<Instruction> instructions = new ArrayList<>();
    protected int locationCounter = 0;

    public AssemblerPassOne() {
        initializeOpCodeTable();
    }

    private void initializeOpCodeTable() {
        opCodeTable.put("LDA", new OpCode("LDA", 3));
        opCodeTable.put("STA", new OpCode("STA", 3));
        opCodeTable.put("ADD", new OpCode("ADD", 3));
        opCodeTable.put("SUB", new OpCode("SUB", 3));
    }

    public void addInstruction(String label, String operation, String operand) {
        Instruction instruction = new Instruction(label, operation, operand);
        instructions.add(instruction);

        if (label != null && !label.isEmpty()) {
            symbolTable.put(label, new Symbol(label, locationCounter));
        }

        if (opCodeTable.containsKey(operation)) {
            locationCounter += opCodeTable.get(operation).format;
        } else if (operation.equals("WORD")) {
            locationCounter += 3;
        } else if (operation.equals("RESW")) {
            int words = Integer.parseInt(operand);
            locationCounter += 3 * words;
        } else if (operation.equals("RESB")) {
            int bytes = Integer.parseInt(operand);
            locationCounter += bytes;
        } else if (operation.equals("BYTE")) {
            locationCounter += 1;
        }
    }

    public void processInstructions() {
        for (Instruction instruction : instructions) {
            String operand = instruction.operand;

            if (operand != null && operand.startsWith("=")) {
                if (!literalTable.containsKey(operand)) {
                    literalTable.put(operand, new Literal(operand, locationCounter));
                    locationCounter += 3;
                }
            }
        }
    }

    public Map<String, Symbol> getSymbolTable() {
        return symbolTable;
    }

    public Map<String, Literal> getLiteralTable() {
        return literalTable;
    }

    public ArrayList<Instruction> getInstructions() {
        return instructions;
    }
}

class AssemblerPassTwo {
    private Map<String, Symbol> symbolTable;
    private Map<String, Literal> literalTable;
    private Map<String, OpCode> opCodeTable;
    private ArrayList<Instruction> instructions;

    public AssemblerPassTwo(AssemblerPassOne passOne) {
        this.symbolTable = passOne.getSymbolTable();
        this.literalTable = passOne.getLiteralTable();
        this.opCodeTable = passOne.opCodeTable;
        this.instructions = passOne.getInstructions();
    }

    public void generateObjectCode() {
        System.out.println("Object Code:");
        
        for (Instruction instruction : instructions) {
            String operation = instruction.operation;
            String operand = instruction.operand;
            StringBuilder objectCode = new StringBuilder();

            if (opCodeTable.containsKey(operation)) {
                objectCode.append(opCodeTable.get(operation).mnemonic).append(" ");
                
                if (operand != null) {
                    if (symbolTable.containsKey(operand)) {
                        objectCode.append(String.format("%04X", symbolTable.get(operand).address));
                    } else if (literalTable.containsKey(operand)) {
                        objectCode.append(String.format("%04X", literalTable.get(operand).address));
                    } else {
                        objectCode.append("????");
                    }
                }
            } else if (operation.equals("WORD")) {
                objectCode.append(String.format("%06X", Integer.parseInt(operand)));
            } else if (operation.equals("BYTE")) {
                if (operand.startsWith("X'") && operand.endsWith("'")) {
                    objectCode.append(operand.substring(2, operand.length() - 1));
                } else if (operand.startsWith("C'") && operand.endsWith("'")) {
                    for (char c : operand.substring(2, operand.length() - 1).toCharArray()) {
                        objectCode.append(String.format("%02X", (int) c));
                    }
                }
            } else if (operation.equals("RESW") || operation.equals("RESB")) {
                objectCode.append("----"); // Placeholder for reserved space
            }

            System.out.println(objectCode.toString());
        }
    }
}

public class TwoPassAssembler {
    public static void main(String[] args) {
        // Pass 1: Assemble Symbol Table and Literal Table
        AssemblerPassOne passOne = new AssemblerPassOne();

        passOne.addInstruction("START", "START", "1000");
        passOne.addInstruction("FIRST", "LDA", "ALPHA");
        passOne.addInstruction("", "ADD", "=5");
        passOne.addInstruction("", "STA", "BETA");
        passOne.addInstruction("ALPHA", "WORD", "1");
        passOne.addInstruction("BETA", "RESW", "1");
        passOne.addInstruction("END", "END", "");

        passOne.processInstructions();

        // Pass 2: Generate Object Code
        AssemblerPassTwo passTwo = new AssemblerPassTwo(passOne);
        passTwo.generateObjectCode();
    }
}
